package com.CarInventery.main;

import java.util.List;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.CarInventery.dao.CarDao;
import com.CarInventery.model.CarPojo;

public class App {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		CarPojo b = (CarPojo) context.getBean("edao");
		String command;
		Scanner scanner = new Scanner(System.in);
		System.out.println("please enter your action what you need perform add,list,quit");
		command = scanner.next();
		while (!command.equals("quit")) {

			switch (command) {
			case "add":
				System.out.println("Welcome To CarInventery System");
				System.out.println("enter the value for make=");
				b.setMake(scanner.next());
				System.out.println("enter the value for model=");
				b.setModel(scanner.next());
				System.out.println("enter the value for year=");
				b.setYear(scanner.nextInt());
				System.out.println("enter the value for price($)=");
				b.setSalesPrice(scanner.nextFloat());
				CarDao dao = context.getBean("cdao", CarDao.class);
				dao.saveCar(b);
				System.out.println("data saved successfully please enter list command");

				System.out.println("please enter your action add,list,quit");
				command = scanner.next();
				break;
			case "list":
				CarDao dao1 = context.getBean("cdao", CarDao.class);
				List<CarPojo> list1 = dao1.getAllCarRowMapper();
				list1.forEach(carInfo -> System.out.println(carInfo));
				System.out.println("please enter your action what you need perform add,list,quit");
				command = scanner.next();
				break;
			default:
				System.out.println("please enter your action what you need perform add,list,quit");
				command = scanner.next();
			}
		}
		System.out.println("Goodbye!!!!!!!!!!!!!!!");
	}
}
