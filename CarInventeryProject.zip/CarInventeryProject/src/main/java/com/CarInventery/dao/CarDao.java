package com.CarInventery.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.CarInventery.model.CarPojo;

public class CarDao {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveCar(CarPojo car) {
		String insertcarInfo = "insert into car values(" + car.getId() + ",'" + car.getMake() + "','" + car.getModel()
				+ "','" + car.getYear() + "','" + car.getSalesPrice() + "')";
		jdbcTemplate.update(insertcarInfo);
	}

	public List<CarPojo> getAllCarRowMapper() {
		return jdbcTemplate.query("select * from car", new RowMapper<CarPojo>() {
			public CarPojo mapRow(ResultSet rs, int rownumber) throws SQLException {
				CarPojo car = new CarPojo();
				car.setId(rs.getInt(1));
				car.setMake(rs.getString(2));
				car.setModel(rs.getString(3));
				car.setYear(rs.getInt(4));
				car.setSalesPrice(rs.getFloat(5));
				return car;
			}
		});
	}
}
